/*
- box-sizing

- Price and shipping side by side
- No floats on colors
- Layout. Image is 250px, and then we want 40px between all elements. So you need to calculate width of the two other ones. If that's too hard, just use a width of 240px
- You will need clearfix class

This will bevome SOOO much easier in flexbox!
*/